
class ChatBot {
    constructor() {
        // Supprimer le slash final de l'URL
        this.apiBase = 'https://4d89add3-51cd-408f-87ec-7ab85617b22e-00-2h6p7hchxyew2.janeway.replit.dev'; // Sans slash final
        this.currentUrl = '';
        this.init();
    }

    async init() {
        await this.getCurrentPageUrl();
        this.setupEventListeners();
        // Maintenant que getCurrentPageUrl() a complété son exécution, this.currentUrl devrait être défini
        this.updateCurrentPageDisplay();
        // Charger l'historique des messages
        this.loadChatHistory();
        this.loadSettings(); // Charger les paramètres
    }

    // Ajouter ces nouvelles méthodes
    loadSettings() {
        chrome.storage.local.get(['aiSettings'], (result) => {
            this.aiSettings = result.aiSettings || {
                temperature: 0.7,
                maxTokens: 1000,
                language: 'auto',
                creativity: 'balanced' // 'factual', 'balanced', 'creative'
            };
        });
    }

    saveSettings() {
        chrome.storage.local.set({ 'aiSettings': this.aiSettings });
    }

    showSettingsModal() {
        // Créer un modal pour les paramètres
        const modal = document.createElement('div');
        modal.className = 'settings-modal';
        modal.innerHTML = `
            <div class="settings-content">
                <h2>Paramètres de l'IA</h2>
                <div class="setting-group">
                    <label>Créativité</label>
                    <select id="creativity">
                        <option value="factual" ${this.aiSettings.creativity === 'factual' ? 'selected' : ''}>Factuel</option>
                        <option value="balanced" ${this.aiSettings.creativity === 'balanced' ? 'selected' : ''}>Équilibré</option>
                        <option value="creative" ${this.aiSettings.creativity === 'creative' ? 'selected' : ''}>Créatif</option>
                    </select>
                </div>
                <div class="setting-group">
                    <label>Langue préférée</label>
                    <select id="language">
                        <option value="auto" ${this.aiSettings.language === 'auto' ? 'selected' : ''}>Auto-détection</option>
                        <option value="fr" ${this.aiSettings.language === 'fr' ? 'selected' : ''}>Français</option>
                        <option value="en" ${this.aiSettings.language === 'en' ? 'selected' : ''}>Anglais</option>
                    </select>
                </div>
                <div class="setting-buttons">
                    <button id="saveSettings">Enregistrer</button>
                    <button id="cancelSettings">Annuler</button>
                </div>
            </div>
        `;
        
        document.body.appendChild(modal);
        
        // Gérer les événements
        document.getElementById('saveSettings').addEventListener('click', () => {
            this.aiSettings.creativity = document.getElementById('creativity').value;
            this.aiSettings.language = document.getElementById('language').value;
            this.saveSettings();
            document.body.removeChild(modal);
            this.setStatus('Paramètres enregistrés', 'success');
            setTimeout(() => this.setStatus(''), 2000);
        });
        
        document.getElementById('cancelSettings').addEventListener('click', () => {
            document.body.removeChild(modal);
        });
    }

    async getCurrentPageUrl() {
        try {
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
            this.currentUrl = tab.url;
        } catch (error) {
            console.error('Error getting current URL:', error);
            this.currentUrl = 'Unable to get current page';
        }
    }

    updateCurrentPageDisplay() {
        const urlElement = document.getElementById('current-url');
        // Vérifier si this.currentUrl est défini avant d'accéder à sa propriété length
        const displayUrl = this.currentUrl && this.currentUrl.length > 50 
            ? this.currentUrl.substring(0, 47) + '...' 
            : this.currentUrl || 'Chargement...';
        urlElement.textContent = `Page actuelle: ${displayUrl}`;
    }

    setupEventListeners() {
        const messageInput = document.getElementById('messageInput');
        const sendButton = document.getElementById('sendButton');
        const quickButtons = document.querySelectorAll('.quick-btn');
        const clearChatBtn = document.getElementById('clearChatBtn');
        const settingsBtn = document.getElementById('settingsBtn');
        settingsBtn.addEventListener('click', () => this.showSettingsModal());
        sendButton.addEventListener('click', () => this.sendMessage());
        messageInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') this.sendMessage();
        });

        quickButtons.forEach(btn => {
            btn.addEventListener('click', () => {
                const action = btn.dataset.action;
                this.handleQuickAction(action);
            });
        });
        
        // Ajout de l'événement pour nettoyer le chat
        clearChatBtn.addEventListener('click', () => this.clearChat());
    }

    // Nouvelle méthode pour nettoyer le chat
    clearChat() {
        const chatMessages = document.getElementById('chatMessages');
        // Garder uniquement le message d'accueil
        chatMessages.innerHTML = `
            <div class="message bot-message">
                <div class="message-content">
                    Bonjour ! Je suis votre assistant IA. Posez-moi des questions sur la page actuelle ou n'importe quoi d'autre !
                </div>
            </div>
        `;
        // Sauvegarder le nouvel état du chat
        this.saveChatHistory();
        // Afficher un message de confirmation
        this.setStatus('Historique effacé', 'success');
        setTimeout(() => this.setStatus(''), 2000);
    }

    async sendMessage() {
        const messageInput = document.getElementById('messageInput');
        const message = messageInput.value.trim();
        
        if (!message) return;

        this.addMessage(message, 'user');
        messageInput.value = '';
        this.setStatus('Traitement en cours...', 'loading');

        try {
            // Analyser le message pour déterminer l'action
            const response = await this.processMessage(message);
            this.addMessage(response, 'bot');
            this.setStatus('');
        } catch (error) {
            this.addMessage('Désolé, une erreur est survenue. Veuillez réessayer.', 'bot');
            this.setStatus('Erreur de traitement', 'error');
        }
    }

    async processMessage(message) {
        const lowerMessage = message.toLowerCase();
        
        // Détection d'intention basique
        if (lowerMessage.includes('analyse') || lowerMessage.includes('résume')) {
            return await this.analyzeCurrentPage(message);
        } else if (lowerMessage.includes('audio') || lowerMessage.includes('mp3')) {
            return await this.convertToAudio();
        } else if (lowerMessage.includes('transcri')) {
            return await this.transcribeAndAnalyze(message);
        } else {
            // Question générale sur la page
            return await this.askAboutPage(message);
        }
    }

    async handleQuickAction(action) {
        this.setStatus('Traitement en cours...', 'loading');
        
        try {
            let response;
            switch (action) {
                case 'analyze-page':
                    response = await this.analyzeCurrentPage('Analyse cette page et donne-moi un résumé détaillé.');
                    break;
                case 'convert-audio':
                    response = await this.convertToAudio();
                    break;
                case 'transcribe':
                    response = await this.transcribeAndAnalyze('Transcris et analyse le contenu de cette page.');
                    break;
            }
            this.addMessage(response, 'bot');
            this.setStatus('');
        } catch (error) {
            this.addMessage('Désolé, une erreur est survenue. Veuillez réessayer.', 'bot');
            this.setStatus('Erreur de traitement', 'error');
        }
    }

    async analyzeCurrentPage(question) {
        try {
            const apiCheck = await fetch(`${this.apiBase}/api/health`, { method: 'GET' })
                .catch(() => ({ ok: false }));
                
            if (!apiCheck.ok) {
                return "❌ L'API n'est pas disponible actuellement. Veuillez vérifier la configuration de l'extension.";
            }
            
            const response = await fetch(`${this.apiBase}/api/n8n-pipeline`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    url: this.currentUrl,
                    question: question,
                    model: "gpt-4o" // Spécifier un modèle plus récent et performant
                })
            });

            const data = await response.json();
            
            if (data.success) {
                // Suppression du lien de téléchargement MP3
                return `📊 **Analyse terminée !**\n\n${data.output.analysis}`;
            } else {
                return `❌ Erreur lors de l'analyse: ${data.message}`;
            }
        } catch (error) {
            throw new Error('Erreur de connexion à l\'API');
        }
    }

    async convertToAudio() {
        try {
            // Vérifier si l'API est disponible
            const apiCheck = await fetch(`${this.apiBase}/api/health`, { method: 'GET' })
                .catch(() => ({ ok: false }));
                
            if (!apiCheck.ok) {
                return "❌ L'API n'est pas disponible actuellement. Veuillez vérifier la configuration de l'extension.";
            }
            
            // Utiliser la méthode POST au lieu de GET
            const response = await fetch(`${this.apiBase}/api/convert`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    url: this.currentUrl
                })
            });
        
            // Vérifier le statut HTTP
            if (!response.ok) {
                const errorText = await response.text();
                console.error(`Erreur API (${response.status}): ${errorText}`);
                return `❌ Erreur lors de la conversion: ${response.status} ${response.statusText}`;
            }
        
            const data = await response.json();
            
            if (data.success) {
                // Suppression du lien de téléchargement
                return `🎵 **Conversion MP3 terminée !**\n\nLe contenu a été converti en audio avec succès.${data.warnings ? '\n\n⚠️ ' + data.warnings.join('\n') : ''}`;
            } else {
                return `❌ Erreur lors de la conversion: ${data.message}`;
            }
        } catch (error) {
            console.error('Erreur complète:', error);
            throw new Error(`Erreur de connexion à l'API: ${error.message}`);
        }
    }

    async transcribeAndAnalyze(question) {
        return await this.analyzeCurrentPage(question);
    }

    async askAboutPage(question) {
        // Pour les questions générales, on utilise l'analyse avec la question spécifique
        return await this.analyzeCurrentPage(question);
    }

    addMessage(content, type) {
        const chatMessages = document.getElementById('chatMessages');
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${type}-message`;
        
        const contentDiv = document.createElement('div');
        contentDiv.className = 'message-content';
        
        // Formatage basique du markdown
        const formattedContent = content
            .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
            .replace(/\n/g, '<br>')
            .replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2" target="_blank">$1</a>');
        
        contentDiv.innerHTML = formattedContent;
        messageDiv.appendChild(contentDiv);
        chatMessages.appendChild(messageDiv);
        
        // Scroll vers le bas
        chatMessages.scrollTop = chatMessages.scrollHeight;
        
        // Sauvegarder l'historique des messages
        this.saveChatHistory();
    }
    
    // Nouvelles méthodes pour gérer l'historique des messages
    saveChatHistory() {
        const chatMessages = document.getElementById('chatMessages');
        chrome.storage.local.set({ 'chatHistory': chatMessages.innerHTML });
    }
    
    loadChatHistory() {
        chrome.storage.local.get(['chatHistory'], (result) => {
            if (result.chatHistory) {
                const chatMessages = document.getElementById('chatMessages');
                chatMessages.innerHTML = result.chatHistory;
            }
        });
    }

    setStatus(message, type = '') {
        const statusElement = document.getElementById('status');
        statusElement.textContent = message;
        statusElement.className = `status ${type}`;
    }
}

// Initialiser le chatbot quand la popup s'ouvre
document.addEventListener('DOMContentLoaded', () => {
    new ChatBot();
});
