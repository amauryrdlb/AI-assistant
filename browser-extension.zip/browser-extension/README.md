
# AI Chatbot - Extension de Navigateur

Extension de navigateur compatible Chrome et Edge pour votre API de conversion URL vers MP3 avec transcription IA.

## Installation

### Pour Chrome et Edge (Développement)

1. Ouvrez Chrome ou Edge
2. Allez dans `chrome://extensions/` (ou `edge://extensions/` pour Edge)
3. Activez le "Mode développeur" en haut à droite
4. Cliquez sur "Charger l'extension non empaquetée"
5. Sélectionnez le dossier `browser-extension`

### Publication sur les stores (Production)

Pour publier sur Chrome Web Store et Microsoft Edge Add-ons:
1. Créez les icônes manquantes (16x16, 32x32, 48x48, 128x128 pixels)
2. Testez l'extension complètement
3. Créez un package ZIP de l'extension
4. Soumettez aux stores respectifs

## Fonctionnalités

- 🤖 Interface de chatbot intuitive
- 📄 Analyse automatique de la page actuelle
- 🎵 Conversion URL vers MP3
- 📝 Transcription et analyse IA
- ⚡ Actions rapides prédéfinies
- 🔗 Compatible avec votre API Replit

## Configuration

1. Modifiez l'URL de l'API dans `popup.js` ligne 3:
   ```javascript
   this.apiBase = 'https://votre-url-replit.replit.app';
   ```

2. Ajoutez vos icônes dans le dossier `icons/`:
   - icon16.png (16x16)
   - icon32.png (32x32) 
   - icon48.png (48x48)
   - icon128.png (128x128)

## Utilisation

1. Cliquez sur l'icône de l'extension dans la barre d'outils
2. L'extension détecte automatiquement l'URL de la page actuelle
3. Utilisez les boutons rapides ou tapez vos questions
4. L'assistant traite vos demandes via votre API

## Actions Rapides

- **Analyser cette page**: Analyse complète du contenu
- **Convertir en audio**: Conversion URL vers MP3
- **Transcrire & analyser**: Pipeline complet avec transcription

## Support

Compatible avec:
- Google Chrome (Manifest V3)
- Microsoft Edge (Manifest V3)
- Toutes les pages web (permissions nécessaires)
