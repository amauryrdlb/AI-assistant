
// Service worker pour gérer les événements en arrière-plan
chrome.runtime.onInstalled.addListener(() => {
    console.log('AI Chatbot Extension installée');
});

// Écouter les messages du content script
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'openPopup') {
        // Ouvrir la popup (cette action est automatique avec manifest v3)
        chrome.action.openPopup();
    }
});

// Gérer les raccourcis clavier (optionnel)
chrome.commands?.onCommand.addListener((command) => {
    if (command === 'open-chatbot') {
        chrome.action.openPopup();
    }
});

// Fonction pour vérifier l'état de l'API
async function checkApiHealth() {
    try {
        const response = await fetch('https://urltomp3api--amauryroulletdeurlto.repl.co/api/health');
        const data = await response.json();
        return data.status === 'healthy';
    } catch (error) {
        console.error('API Health Check Failed:', error);
        return false;
    }
}

// Vérifier l'API périodiquement
setInterval(checkApiHealth, 5 * 60 * 1000); // Toutes les 5 minutes
