
// Content script pour interagir avec la page web
(function() {
    'use strict';
    
    // Fonction pour extraire des informations de la page
    function getPageInfo() {
        return {
            title: document.title,
            url: window.location.href,
            text: document.body.innerText.substring(0, 5000), // Limiter à 5000 caractères
            meta: {
                description: document.querySelector('meta[name="description"]')?.content || '',
                keywords: document.querySelector('meta[name="keywords"]')?.content || '',
                author: document.querySelector('meta[name="author"]')?.content || ''
            }
        };
    }

    // Écouter les messages de l'extension
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
        if (request.action === 'getPageInfo') {
            sendResponse(getPageInfo());
        }
    });

    // Injecter un indicateur visuel quand l'extension est active
    function showExtensionIndicator() {
        const indicator = document.createElement('div');
        indicator.id = 'ai-chatbot-indicator';
        indicator.innerHTML = '🤖 AI Assistant actif';
        indicator.style.cssText = `
            position: fixed;
            top: 10px;
            right: 10px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 8px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            z-index: 10000;
            box-shadow: 0 2px 10px rgba(0,0,0,0.2);
            backdrop-filter: blur(10px);
            opacity: 0.9;
            transition: all 0.3s ease;
            cursor: pointer;
        `;
        
        indicator.addEventListener('mouseenter', () => {
            indicator.style.opacity = '1';
            indicator.style.transform = 'scale(1.05)';
        });
        
        indicator.addEventListener('mouseleave', () => {
            indicator.style.opacity = '0.9';
            indicator.style.transform = 'scale(1)';
        });
        
        indicator.addEventListener('click', () => {
            chrome.runtime.sendMessage({action: 'openPopup'});
        });
        
        document.body.appendChild(indicator);
        
        // Masquer l'indicateur après 3 secondes
        setTimeout(() => {
            indicator.style.opacity = '0';
            setTimeout(() => {
                if (indicator.parentNode) {
                    indicator.parentNode.removeChild(indicator);
                }
            }, 300);
        }, 3000);
    }

    // Afficher l'indicateur quand la page se charge
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', showExtensionIndicator);
    } else {
        showExtensionIndicator();
    }
})();
